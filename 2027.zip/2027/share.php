<?php
error_reporting(0);
ini_set('display_errors', 0);

define('DB_HOST', 'sql308.infinityfree.com');
define('DB_NAME', 'if0_42664773_gameport');
define('DB_USER', 'if0_42664773');
define('DB_PASS', 'weIfUGkedz2QX');
define('UPLOAD_DIR', __DIR__ . '/uploads/');

function getDB() {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die('数据库连接失败');
    }
}

$filename = isset($_GET['file']) ? $_GET['file'] : '';
if (empty($filename)) {
    die('参数错误');
}
$filename = basename($filename);
$filePath = UPLOAD_DIR . $filename;

if (!file_exists($filePath)) {
    die('文件不存在或已被删除');
}

$pdo = getDB();
$stmt = $pdo->prepare("SELECT filename, filepath, uploader, upload_time FROM files WHERE filename = ?");
$stmt->execute([$filename]);
$fileInfo = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$fileInfo) {
    die('文件记录不存在');
}

$fileSize = filesize($filePath);
$fileSizeMB = round($fileSize / 1024 / 1024, 2);
$fileExt = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

function getFileIcon($ext) {
    $map = [
        'mp3' => '🎵', 'wav' => '🎵', 'flac' => '🎵', 'aac' => '🎵', 'ogg' => '🎵', 'wma' => '🎵', 'm4a' => '🎵',
        'mp4' => '🎬', 'avi' => '🎬', 'mkv' => '🎬', 'mov' => '🎬', 'wmv' => '🎬', 'flv' => '🎬', 'webm' => '🎬',
        'jpg' => '🖼️', 'jpeg' => '🖼️', 'png' => '🖼️', 'gif' => '🖼️', 'webp' => '🖼️', 'bmp' => '🖼️', 'svg' => '🖼️',
        'pdf' => '📄', 'doc' => '📝', 'docx' => '📝', 'txt' => '📃',
        'zip' => '📦', 'rar' => '📦', '7z' => '📦', 'tar' => '📦', 'gz' => '📦',
        'apk' => '📱', 'exe' => '⚙️', 'iso' => '💿'
    ];
    return $map[$ext] ?? '📄';
}
$icon = getFileIcon($fileExt);

session_start();
$isLoggedIn = false;
$userName = '';

if (isset($_SESSION['user_id']) && isset($_SESSION['user_token'])) {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $isLoggedIn = true;
        $userName = $user['username'];
    }
}

if (!$isLoggedIn && isset($_COOKIE['user_id']) && isset($_COOKIE['user_token'])) {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$_COOKIE['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $_SESSION['user_id'] = $_COOKIE['user_id'];
        $_SESSION['user_token'] = $_COOKIE['user_token'];
        $isLoggedIn = true;
        $userName = $user['username'];
    }
}

$downloadCount = 0;
$showLoginPrompt = false;
if (!$isLoggedIn) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $key = 'download_' . md5($ip . '_' . $filename);
    $stmt = $pdo->prepare("SELECT download_count FROM download_logs WHERE log_key = ?");
    $stmt->execute([$key]);
    $log = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($log) {
        $downloadCount = (int)$log['download_count'];
        if ($downloadCount >= 5) {
            $showLoginPrompt = true;
        }
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'download') {
    if (!$isLoggedIn) {
        $ip = $_SERVER['REMOTE_ADDR'];
        $key = 'download_' . md5($ip . '_' . $filename);
        $stmt = $pdo->prepare("SELECT download_count FROM download_logs WHERE log_key = ?");
        $stmt->execute([$key]);
        $log = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($log && (int)$log['download_count'] >= 5) {
            http_response_code(403);
            echo json_encode(['error' => '下载次数已达上限，请登录后下载']);
            exit;
        }
        if ($log) {
            $stmt = $pdo->prepare("UPDATE download_logs SET download_count = download_count + 1 WHERE log_key = ?");
            $stmt->execute([$key]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO download_logs (log_key, filename, download_count) VALUES (?, ?, 1)");
            $stmt->execute([$key, $filename]);
        }
    }
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>文件分享 - <?php echo htmlspecialchars($filename); ?></title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{min-height:100vh;display:flex;justify-content:center;align-items:center;background:linear-gradient(135deg,#0b0f16,#1a1f2e);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;padding:20px}
        .login-btn{position:fixed;top:20px;left:20px;width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,#ff5e00,#e64a00);color:#fff;border:none;font-size:18px;font-weight:700;cursor:pointer;box-shadow:0 4px 15px rgba(255,94,0,0.3);transition:.3s;z-index:100;display:flex;align-items:center;justify-content:center;text-decoration:none;overflow:hidden}
        .login-btn:hover{transform:scale(1.05);box-shadow:0 6px 25px rgba(255,94,0,0.4)}
        .login-btn.logged{background:#2a313c;box-shadow:0 4px 15px rgba(0,0,0,0.3)}
        .login-btn .avatar-text{font-size:16px;font-weight:600;color:#f0e6d0}
        .card{background:#12161e;padding:50px 40px;border-radius:20px;border:1px solid #2a313c;box-shadow:0 12px 40px rgba(0,0,0,0.5);width:100%;max-width:480px;text-align:center;margin-top:30px}
        .icon{font-size:80px;display:block;margin-bottom:16px}
        .filename{color:#f0e6d0;font-size:22px;font-weight:600;word-break:break-all;margin-bottom:8px}
        .meta{color:#6b7a8f;font-size:14px;margin-bottom:6px}
        .meta span{color:#66d9a8}
        .size-info{color:#4b5a6e;font-size:13px;margin-bottom:25px}
        .btn-download{width:100%;padding:16px;background:linear-gradient(135deg,#ff5e00,#e64a00);color:#fff;border:none;border-radius:12px;font-size:18px;font-weight:700;cursor:pointer;transition:.3s}
        .btn-download:hover{transform:translateY(-2px);box-shadow:0 5px 20px rgba(255,94,0,0.3)}
        .btn-download:disabled{background:#3d4a5a;cursor:not-allowed;transform:none;box-shadow:none}
        .btn-download .size{font-weight:400;font-size:14px;opacity:.8}
        .login-prompt{background:#2a0f12;color:#f28b82;border:1px solid #5c2020;padding:14px;border-radius:10px;margin-top:16px;font-size:14px}
        .login-prompt a{color:#ff5e00;text-decoration:none}
        .login-prompt a:hover{text-decoration:underline}
        .download-count{color:#4b5a6e;font-size:12px;margin-top:12px}
        .footer{margin-top:20px;font-size:10px;color:#3d4a5a;border-top:1px solid #1f2632;padding-top:14px}
        .footer span{color:#ff5e00}
        .toast{position:fixed;bottom:30px;left:50%;transform:translateX(-50%);background:#2a0f12;color:#f28b82;padding:12px 24px;border-radius:10px;border:1px solid #5c2020;font-size:14px;display:none;z-index:999;box-shadow:0 8px 30px rgba(0,0,0,0.6)}
        .modal-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);display:none;justify-content:center;align-items:center;z-index:1000}
        .modal{background:#12161e;padding:30px 35px;border-radius:16px;border:1px solid #2a313c;max-width:380px;width:90%;text-align:center}
        .modal h3{color:#f0e6d0;font-size:18px;margin-bottom:10px}
        .modal p{color:#6b7a8f;font-size:14px;margin-bottom:20px}
        .modal .btn-group{display:flex;gap:12px;justify-content:center}
        .modal .btn-group button{padding:10px 28px;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;transition:.3s}
        .modal .btn-primary{background:linear-gradient(135deg,#ff5e00,#e64a00);color:#fff}
        .modal .btn-primary:hover{transform:scale(1.02)}
        .modal .btn-secondary{background:#2a313c;color:#b7c4d4}
        .modal .btn-secondary:hover{background:#3d4a5a}
        @media(max-width:480px){.card{padding:30px 20px}.login-btn{top:12px;left:12px;width:38px;height:38px;font-size:14px}}
    </style>
</head>
<body>

<div class="toast" id="toast">⚠️ 下载次数已达上限，请登录后下载</div>

<a href="javascript:void(0)" class="login-btn <?php echo $isLoggedIn ? 'logged' : ''; ?>" id="loginBtn" onclick="handleLoginClick()">
    <?php if ($isLoggedIn): ?>
        <span class="avatar-text"><?php echo mb_substr($userName, 0, 1); ?></span>
    <?php else: ?>
        <span style="font-size:20px;">👤</span>
    <?php endif; ?>
</a>

<div class="modal-overlay" id="modalOverlay">
    <div class="modal">
        <h3 id="modalTitle">提示</h3>
        <p id="modalMessage">内容</p>
        <div class="btn-group">
            <button class="btn-primary" id="modalConfirm">确定</button>
            <button class="btn-secondary" id="modalCancel">取消</button>
        </div>
    </div>
</div>

<div class="card">
    <span class="icon"><?php echo $icon; ?></span>
    <div class="filename"><?php echo htmlspecialchars($filename); ?></div>
    <div class="meta">👤 上传者：<span><?php echo htmlspecialchars($fileInfo['uploader']); ?></span></div>
    <div class="meta">🕐 上传时间：<?php echo htmlspecialchars($fileInfo['upload_time']); ?></div>
    <div class="size-info">📦 文件大小：<strong><?php echo $fileSizeMB; ?> MB</strong></div>
    <?php if ($showLoginPrompt): ?>
        <div class="login-prompt">⚠️ 你当前的免费下载次数已用完（5次/文件）<br>请 <a href="index.html">登录</a> 后无限下载</div>
        <button class="btn-download" disabled>⛔ 下载次数已用完</button>
    <?php else: ?>
        <button class="btn-download" id="downloadBtn" onclick="downloadFile()">⬇️ 下载文件 <span class="size">(<?php echo $fileSizeMB; ?> MB)</span></button>
        <?php if (!$isLoggedIn): ?>
            <div class="download-count">📌 剩余下载次数：<?php echo max(0, 5 - $downloadCount); ?> 次（未登录）</div>
        <?php endif; ?>
    <?php endif; ?>
    <div class="footer">⚡ 由 <span>龙黑化</span> 提供文件分享服务</div>
</div>

<script>
if (!sessionStorage.getItem('reloaded_share')) {
    sessionStorage.setItem('reloaded_share', '1');
    location.reload();
}

var modalOverlay = document.getElementById('modalOverlay');
var modalTitle = document.getElementById('modalTitle');
var modalMessage = document.getElementById('modalMessage');
var modalConfirm = document.getElementById('modalConfirm');
var modalCancel = document.getElementById('modalCancel');

function showModal(title, message, confirmText, cancelText, onConfirm, onCancel) {
    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modalConfirm.textContent = confirmText || '确定';
    modalCancel.textContent = cancelText || '取消';
    modalOverlay.style.display = 'flex';
    modalConfirm.onclick = function() {
        modalOverlay.style.display = 'none';
        if (onConfirm) onConfirm();
    };
    modalCancel.onclick = function() {
        modalOverlay.style.display = 'none';
        if (onCancel) onCancel();
    };
}

function closeModal() {
    modalOverlay.style.display = 'none';
}

function handleLoginClick() {
    <?php if ($isLoggedIn): ?>
        showModal(
            '返回主界面',
            '您已登录，是否返回主界面 dashboard.html？',
            '返回主界面',
            '留在当前页面',
            function() {
                window.location.href = 'dashboard.html';
            },
            function() {
                closeModal();
            }
        );
    <?php else: ?>
        window.location.href = 'index.html';
    <?php endif; ?>
}

function downloadFile() {
    var btn = document.getElementById('downloadBtn');
    btn.disabled = true;
    btn.textContent = '⏳ 下载中...';
    var url = window.location.href;
    if (url.indexOf('?') > -1) {
        url += '&action=download';
    } else {
        url += '?action=download';
    }
    fetch(url, {
        method: 'GET',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(function(response) {
        if (response.status === 403) {
            return response.json().then(function(data) {
                throw new Error(data.error || '下载次数已达上限');
            });
        }
        if (!response.ok) {
            throw new Error('下载失败');
        }
        window.location.href = url;
    })
    .catch(function(err) {
        var toast = document.getElementById('toast');
        toast.textContent = '⚠️ ' + err.message;
        toast.style.display = 'block';
        setTimeout(function() {
            toast.style.display = 'none';
        }, 4000);
        btn.disabled = false;
        btn.innerHTML = '⬇️ 下载文件 <span class="size">(<?php echo $fileSizeMB; ?> MB)</span>';
    });
}

modalOverlay.addEventListener('click', function(e) {
    if (e.target === modalOverlay) {
        modalOverlay.style.display = 'none';
    }
});
</script>
</body>
</html>