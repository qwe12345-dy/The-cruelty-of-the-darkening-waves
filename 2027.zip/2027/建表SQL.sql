-- ============================================================
-- 龙黑化社区 建表 SQL（在 phpMyAdmin / SQL 面板中整段执行即可）
-- 数据库：ezyro_42734402_123
-- 说明：所有表都用 CREATE TABLE IF NOT EXISTS，已存在的表不会重复创建、不会覆盖
-- ============================================================

-- 1. 用户表
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  rcoins INT DEFAULT 100,
  gender VARCHAR(10) DEFAULT '',
  bio TEXT,
  bio_status VARCHAR(20) DEFAULT 'pending',
  bio_error TEXT,
  avatar VARCHAR(500) DEFAULT '',
  cover VARCHAR(500) DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. 用户作品表（2.0编辑器 / 上传游戏共用）
CREATE TABLE IF NOT EXISTS user_games (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  username VARCHAR(50) DEFAULT '',
  title VARCHAR(100) NOT NULL,
  icon VARCHAR(500) DEFAULT '',
  description TEXT,
  file_path VARCHAR(500) DEFAULT '',
  status VARCHAR(20) DEFAULT 'pending',
  error_msg TEXT,
  views INT DEFAULT 0,
  unique_views INT DEFAULT 0,
  likes INT DEFAULT 0,
  collects INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. 关注表
CREATE TABLE IF NOT EXISTS user_follows (
  id INT AUTO_INCREMENT PRIMARY KEY,
  follower_id INT NOT NULL,
  following_id INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_follow (follower_id, following_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. 好友关系表（关键：好友私信依赖它）
CREATE TABLE IF NOT EXISTS user_friends (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  friend_id INT NOT NULL,
  status VARCHAR(20) DEFAULT 'accepted',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_pair (user_id, friend_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. 好友邀请表
CREATE TABLE IF NOT EXISTS friend_invites (
  id INT AUTO_INCREMENT PRIMARY KEY,
  from_user_id INT NOT NULL,
  to_user_id INT NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_to (to_user_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. 好友私信表（关键：本次"消息记录为空 / 无法发送"就缺这张表）
CREATE TABLE IF NOT EXISTS private_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sender_id INT NOT NULL,
  receiver_id INT NOT NULL,
  content TEXT NOT NULL,
  is_read TINYINT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_receiver (receiver_id, is_read),
  KEY idx_pair (sender_id, receiver_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. 点赞表
CREATE TABLE IF NOT EXISTS game_likes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  game_id INT NOT NULL,
  user_id INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_like (game_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. 收藏表
CREATE TABLE IF NOT EXISTS game_collects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  game_id INT NOT NULL,
  user_id INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_collect (game_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. 评论表
CREATE TABLE IF NOT EXISTS game_comments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  game_id INT NOT NULL,
  user_id INT NOT NULL,
  username VARCHAR(50) DEFAULT '',
  content TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_game (game_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. 作品访问去重表
CREATE TABLE IF NOT EXISTS game_visits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  game_id INT NOT NULL,
  user_id INT NOT NULL,
  visited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_visit (game_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. 在线人数表
CREATE TABLE IF NOT EXISTS game_online (
  id INT AUTO_INCREMENT PRIMARY KEY,
  game_id INT NOT NULL,
  user_id INT NOT NULL,
  last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_online (game_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. 站内信表
CREATE TABLE IF NOT EXISTS user_mails (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  title VARCHAR(200) DEFAULT '',
  content TEXT,
  is_read TINYINT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. 防重放 nonce 表
CREATE TABLE IF NOT EXISTS used_nonces (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nonce VARCHAR(100) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_nonce (nonce)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. R币转账记录表
CREATE TABLE IF NOT EXISTS rcoin_transfers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  from_user_id INT NOT NULL,
  to_user_id INT NOT NULL,
  game_id INT DEFAULT 0,
  amount INT NOT NULL,
  from_ip VARCHAR(50) DEFAULT '',
  status TINYINT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_from (from_user_id),
  KEY idx_to (to_user_id),
  KEY idx_game (game_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 15. 勋章定义表
CREATE TABLE IF NOT EXISTS badges (
  id INT AUTO_INCREMENT PRIMARY KEY,
  badge_key VARCHAR(50) NOT NULL,
  name VARCHAR(100) DEFAULT '',
  icon VARCHAR(500) DEFAULT '',
  color VARCHAR(20) DEFAULT '',
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_key (badge_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 16. 用户勋章表
CREATE TABLE IF NOT EXISTS user_badges (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  badge_id INT NOT NULL,
  earned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_ub (user_id, badge_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 17. 兑换码表
CREATE TABLE IF NOT EXISTS exchange_codes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code_name VARCHAR(100) DEFAULT '',
  code_key VARCHAR(100) NOT NULL,
  reward_rcoins INT DEFAULT 0,
  max_use_per_user INT DEFAULT 1,
  max_total_uses INT DEFAULT 0,
  total_uses INT DEFAULT 0,
  expire_time DATETIME DEFAULT NULL,
  single_account_only TINYINT DEFAULT 0,
  is_active TINYINT DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_code (code_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 18. 兑换码使用记录表
CREATE TABLE IF NOT EXISTS exchange_usage (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code_id INT NOT NULL,
  user_id INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_code (code_id),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 19. 默认勋章数据（若 badges 表里还没有蓝V / 彩V，则补入）
INSERT IGNORE INTO badges (badge_key, name, icon, color, description) VALUES
('blue_v', '蓝V认证', '', '#2f6fed', '平台官方认证用户'),
('colorful_v', '彩V认证', '', '#ff6b35', '内容优质认证用户');

-- ============================================================
-- 若私信/好友功能报"表不存在"，大概率就是上面第 4/5/6 张表没建。
-- 全表执行完后再刷新页面即可。
-- ============================================================
